# Experiment Goal Design

**Version:** 1.0.0

Use this Skill after an idea or hypothesis exists and before implementation. It aligns goals to relevant field literature and official benchmark protocols, and requires strict evidence for numerical gates.

## Included files

- `SKILL.md` — workflow and handoff
- `references/evidence-and-thresholds.md` — source appraisal and numerical decision rules
- `templates/experiment_goal_contract.template.yaml` — claim and goal contract
- `templates/comparability_matrix.template.csv` — paper/protocol comparison ledger
- `templates/goal_design_note.template.md` — concise decisions and unresolved issues

The Skill defaults to one run/seed per condition. Additional runs are optional unless required by the declared claim or official protocol. It never treats a guessed score gain, p-value, dataset count, or seed count as a valid gate.
