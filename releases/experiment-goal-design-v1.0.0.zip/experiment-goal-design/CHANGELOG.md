# Changelog

## 1.0.0

- Initial release: define claim-aligned goals using a source-linked comparability map.
- Require evidence and applicability for every numerical decision threshold; unsupported cutoffs are removed rather than guessed.
- Make one run/seed the default and treat additional repeats as optional unless the claim or official protocol requires them.
- Add a reusable experiment goal contract template and threshold-evidence guidance.
