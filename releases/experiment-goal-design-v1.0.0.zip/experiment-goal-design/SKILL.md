---
name: experiment-goal-design
description: Use after a research idea or hypothesis exists to turn its claims into literature-aligned, benchmark-comparable experiment goals and evidence-backed decision criteria before implementation or execution.
---

# Experiment Goal Design

Turn a proposed research claim into a reviewable experiment goal whose datasets, scope, baselines, metrics, and evaluation protocol can be defended against the closest relevant field work. Make every numerical pass/fail or continue/stop threshold traceable to an applicable source or an explicit, defensible derivation. Never invent a cutoff to make a plan look decisive.

This Skill is for **designing what an experiment must answer**, not generating research ideas, reconstructing a specific published experiment, implementing runs, or analyzing completed data. Route those tasks to `research-idea-scout`, `paper-reproduction`, `experiment-execution`, and `scientific-data-analysis` as appropriate. It can hand an approved goal contract to `experiment-execution`.

## Non-negotiable decisions

- A research claim does not need an arbitrary numeric success bar. A directional hypothesis, a defined estimand, and an analysis that reports the estimate with appropriate uncertainty can be a complete goal.
- Do not invent numeric targets such as “improve by 3%”, a minimum number of datasets, a universal sample/seed count, a p-value cutoff, or a compute limit. Every number that changes a scientific or operational decision needs an evidence record. Structural values and user-provided constraints are labeled as such, not misrepresented as scientific thresholds.
- Use the benchmark's complete official evaluation scope and protocol for benchmark claims. Do not choose a convenient subset, alternate loader, split, or metric to make a goal easier to pass. If the research question is intentionally narrower, label that scope accurately and do not present it as a full-benchmark result.
- One run/seed per condition is the default. More runs are optional; add them only when the benchmark protocol or the stated claim requires between-run uncertainty, a predeclared inferential design, or a defined selection/optimization question. Do not add a seed grid just to satisfy a generic convention or improve a reported score. A single run cannot support a claim about run-to-run variability.
- Keep the goal, threshold rationale, and comparator evidence frozen before examining outcomes that could influence them. Any change after outcome access must be dated, justified, and labeled exploratory or post hoc.
- A cited paper is not automatically comparable because it is recent, highly cited, or from a top venue. Match the study to the claim, population/task, benchmark version, split, metric, protocol, baseline, and analysis. Record consequential mismatches.

## Workflow

### 1. Define the claim before choosing a score

Read the supplied idea, hypothesis, relevant findings, and literature. State:

- the scientific question and intended contribution;
- the claim type (comparative performance, mechanism, generalization, robustness, efficiency, causal effect, or another explicit category);
- the target population, task, setting, and scope of inference;
- what observation would weaken or falsify the claim;
- what this experiment can and cannot establish.

Split compound claims into independently testable claims. Do not turn aspirations into achieved goals. A falsifier can be a design or pattern of evidence and need not be a fabricated numeric cutoff.

### 2. Find the field's applicable evidence and rules

Use `literature-research` when a search, screening, or source-conflict workflow is needed. Prefer primary sources and inspect the version that actually defines the protocol. Search the target field's official benchmark documentation, benchmark papers, relevant reporting/statistical standards, and closest peer-reviewed studies in the venues that shape the field. Record stable identifiers, publication/version status, date accessed for mutable guidance, and precise section/table/appendix/code locators.

Use a source hierarchy that fits the decision:

1. **Official protocol or rule** for a named benchmark, task, clinical/field standard, or requested venue. This controls compliance only within its stated scope.
2. **Field-specific consensus or reporting/statistical guidance** for design, measurement, uncertainty, and reporting. A reporting checklist is not a universal scientific effect threshold.
3. **Directly comparable peer-reviewed studies** for observed prior results and design practice. Prefer studies matching the target task and protocol; record version and comparability limitations.
4. **Prospective derivation** from a declared estimand, analysis model, empirical variance source, or explicit resource budget. Show the inputs and calculation; label assumptions and sensitivity.

Do not use citation counts, one convenient paper, or a generic “common practice” statement as sufficient evidence for a numeric gate. If sources conflict, record the conflict and explain which source controls this exact question; do not silently select the more favorable value. Read [references/evidence-and-thresholds.md](references/evidence-and-thresholds.md) for source appraisal and threshold handling.

### 3. Build the comparability map

For each anchor study or standard that materially informs the goal, record at least:

- exact source identity and version, venue/year, and evidence locator;
- dataset/benchmark version, official task/track, population, and split;
- loader/preprocessing and evaluation harness where available;
- primary metric, unit, aggregation, and direction;
- baselines and their versions/checkpoints;
- training/tuning/evaluation protocol and any selection rule;
- uncertainty/statistical analysis and the source of variation;
- compute/resource context when it affects fairness or feasibility;
- match status and every mismatch that limits transfer to the proposed claim.

Choose comparisons that answer the claim, not a fixed number of papers or datasets. Distinguish benchmark compliance from scientific comparability: a correct score on one official benchmark does not establish broader generalization. Do not average incompatible datasets or metrics without a justified estimand and analysis.

### 4. Write a claim-to-goal contract

Create `experiment_goal_contract.yaml` from [templates/experiment_goal_contract.template.yaml](templates/experiment_goal_contract.template.yaml). For every claim, specify:

- one research question and testable hypothesis/estimand;
- the official benchmark scope and the exact source defining it, where a benchmark is used;
- the primary metric and aggregation from the benchmark or field protocol;
- a strong, relevant comparator set and why each is fair;
- the intended analysis unit and uncertainty method, including their assumptions;
- a falsification interpretation and claim limit;
- optional secondary, robustness, or ablation goals only when they resolve a stated uncertainty;
- a seed/run plan. Default to one run per condition; justify any extra repeats against the claim or protocol before seeing results.

Use a threshold only when the decision genuinely needs one. Put every numeric outcome, inference, resource, or readiness cutoff that can change a decision into the `decision_thresholds` register. See [references/evidence-and-thresholds.md](references/evidence-and-thresholds.md) for required fields and disposition when evidence is absent. A numeric value appearing only in prose is still a threshold and must be registered.

### 5. Review for evidence alignment and avoid gate creep

Before handoff, check that:

- each goal directly tests a named claim and has an interpretable falsifier;
- the closest relevant protocols, benchmarks, and strong baselines have been compared, with mismatches disclosed;
- the task list, split, metric, loader, and evaluator are official for any full-benchmark claim;
- no dataset/condition/run-count/score threshold was introduced merely because it is conventional or easy to state;
- every numeric threshold has a complete, applicable rationale frozen before outcome access;
- seed count is not treated as a proxy for benchmark coverage, claim quality, or scientific validity;
- exploratory goals, confirmatory claims, and post hoc decisions are clearly distinguished;
- resource constraints are real and sourced, and do not quietly alter scientific scope.

If a proposed numeric threshold has no strong, applicable basis, do **not** guess and do not block all experimentation just to manufacture one. Remove the pass/fail gate; state the goal as estimation/comparison with suitable uncertainty, or mark the specific decision as unresolved and ask the research owner to settle the scientific tradeoff. Do not call an unsupported goal “confirmatory.” If a required official protocol is missing or the full declared scope cannot be run, record that blocker rather than silently relaxing the scope.

### 6. Handoff

Deliver the completed contract, comparator evidence, and any unresolved decisions. Send the approved protocol and contract to `experiment-execution` for campaign/run preflight. Use `scientific-data-analysis` for a prospective power/precision plan or later statistical analysis. The handoff does not itself authorize running experiments.

## Output

- `experiment_goal_contract.yaml` — claims, scope, metrics, comparators, analysis, run plan, and threshold register;
- `comparability_matrix.csv` — source-linked comparison of the relevant protocols and their transfer limits;
- a short `goal_design_note.md` — decision rationale, unresolved evidence gaps, and handoff status.

Keep the output proportional to the study. Do not create a large literature review when a well-supported benchmark protocol and a small number of directly relevant studies settle the design question.
