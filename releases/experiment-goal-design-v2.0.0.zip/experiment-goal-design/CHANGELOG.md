# Changelog

## 2.0.0

- Forbid hand-picked subsets of named official benchmarks, including when a narrower claim is asserted; require full official scope or another complete population/official track.
- Add a concrete anchor-source selection and representativeness procedure without imposing a paper-count quota.
- Record the experimental factor, controlled variables, and protocol deviations in the goal and comparison artifacts.
- Align numeric threshold fields and evidence categories with the `experiment-execution` campaign schema and document the one-to-one handoff map.
- Support multiple threshold sources, add a decision owner, and limit resource/repository constraints to operational gates rather than scientific success criteria.
- Clarify that `research-idea-scout` is optional and may not be installed with AutoSCI.

## 1.0.0

- Initial release: define claim-aligned goals using a source-linked comparability map.
- Require evidence and applicability for every numerical decision threshold; unsupported cutoffs are removed rather than guessed.
- Make one run/seed the default and treat additional repeats as optional unless the claim or official protocol requires them.
- Add a reusable experiment goal contract template and threshold-evidence guidance.
