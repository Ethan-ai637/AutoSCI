# Experiment Goal Design Note

## Research claim and intended scope

## Closest relevant protocols and studies

## Chosen datasets, baselines, metrics, and comparability rationale

## Experimental factor, controls, and protocol deviations

## Numeric decision thresholds

List only thresholds that have a complete source/derivation record in `experiment_goal_contract.yaml`. Write `None` when the experiment is designed for estimation/comparison without a decision cutoff.

## Run/seed rationale

## Unresolved evidence gaps and decisions

## Handoff

State whether the contract is ready for `experiment-execution`, remains exploratory, or has a specific blocker. Do not imply execution has occurred.
